const Driver = require('../models/drivers');
const bcrypt = require('bcrypt');
class driverController{
    static login = (req,res) =>{
        res.render('./driver/login')
    }
    static verifyLogin = async (req,res) =>{
        try {
            const {email, password} = req.body;
            const result = await Driver.findOne({email:email});

            if(result != null){

                const isMatch = await bcrypt.compare(password, result.password)

                if(result.email == email && isMatch ){
                    res.send("<h1>DashBoard</h1>")
                }else{
                    res.send("<h1>Invalid Email and Passwaord</h1>")
                }

            }else{
                res.send("<h1>You are Not Register User</h1>")
            } 
        } catch (error) {
            res.send(error.message);
        }
    }

    
    static register = (req,res) =>{
        res.render('./driver/register')
    }
    static create = async (req,res) =>{
        try {
            if(req.body.password === req.body.cpassword){
                const HashPassword = await bcrypt.hash(req.body.password, 10)
                req.body.password = HashPassword
                const {name, email, password,cnic,contact,vehicle_type,address,experience,vehicle,licience} = req.body;
                const user = new Driver({
                    name, email, password,cnic,contact,vehicle_type,address,experience,vehicle,licience});
                await user.save();
                res.redirect('/driver/login');
            }else{
                res.send("<h1> Password Not Matched </h1>")
            }
         } catch (error) {
         res.send(error.message);
        }
    }
}

module.exports = driverController;