const mongoose = require("mongoose");

// define User Schema
const DriverSchema = new mongoose.Schema({
  name: {
    type: String,
    minlength: 4,
    maxlength: 30,
    required: true,
  },
  password: {
    type: String,
    minlength: 8,
    required: true,
  },
  email:{
    type: String,
    minlength: 4,
    required: true,
    unique: true
  },
  cnic: {
    type: String,
    maxlength: 15,
    required: true,
  },
  contact: {
    type: String,
    maxlength: 12,
    required: true,
  },
licience: {
    type: String,
    minlength: 4,
    required: true,
    unique: true
},
vehicle: {
    type: String,
    minlength: 4,
    required: true,
    unique: true
},
experience:{
    type: String,
    minlength: 1,
    required: true
},
address:{
    type: String,
    minlength: 5,
    required: true
},
vehicle_type: {
    type: String,
    minlength: 4,
    required: true
},
status:{
  type: String,
  required: true
}
});

// Model 
const Driver = mongoose.model("driver", DriverSchema);

module.exports = Driver;