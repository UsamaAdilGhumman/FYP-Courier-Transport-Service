const express = require('express');
const bp = require('body-parser');
const app = express();
const port = process.env.PORT || 5000
const session = require("express-session")
const { v4: uuidv4 } = require('uuid');

// DB Connection
require("./db/conn");

// Import Routes
const web = require("./routes/web");


// Other Files
app.use(bp.json())
app.use(bp.urlencoded({ extended: true }))
// static floders
app.use(express.static(__dirname + '/public'));
// set the view engine to ejs
app.set('view engine', 'ejs');

// use session
app.use(session({
  secret: uuidv4(),
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false , maxAge: 60000 }
}))

// Load Routes
app.use(web);


app.listen(port, () => {
  console.log(`Server Start on port ${port}`)
})