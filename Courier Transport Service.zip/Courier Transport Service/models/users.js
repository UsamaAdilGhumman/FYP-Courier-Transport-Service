const mongoose = require("mongoose");

// define User Schema
const UserSchema = new mongoose.Schema({
  name: {
    type: String,
    minlength: 4,
    maxlength: 30,
    required: true,
  },
  password: {
    type: String,
    minlength: 8,
    required: true,
  },
  email:{
    type: String,
    minlength: 4,
    required: true,
    unique: true
  },
  cnic: {
    type: String,
    maxlength: 15,
    required: true,
  },
  contact: {
    type: String,
    maxlength: 12,
    required: true,
  }
});

// Model 
const User = mongoose.model("User", UserSchema);

module.exports = User;