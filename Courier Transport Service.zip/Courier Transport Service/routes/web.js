const express = require('express');
const router = new express.Router();
const userController = require('../controllers/userController')
const driverController = require('../controllers/driverController')

// Main Screen Routes
router.get('/',userController.index)
router.get('/about',userController.about)
router.get('/contact',userController.contact)
router.post('/contact',userController.contactform)


// User Routes
router.get('/user/login',userController.login)
router.post('/user/login',userController.verifyLogin)
router.get('/user/register',userController.register)
router.post('/user/register',userController.create)
router.get('/user/dashboard',userController.dashboard)
router.get('/user/setting',userController.setting)
router.get('/user/logout',userController.logout)
router.get('/user/request',userController.request)

// Driver Routes
router.get('/driver/login',driverController.login)
router.post('/driver/login',driverController.verifyLogin)
router.get('/driver/register',driverController.register)
router.post('/driver/register',driverController.create)



module.exports = router;
