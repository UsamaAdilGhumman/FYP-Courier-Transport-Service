const User = require('../models/users');
const bcrypt = require('bcrypt');
const nodemailer = require("nodemailer");
class userController{
    static index = (req, res) => {
        res.render('index',{ user: req.session.email })
      }
      static dashboard = async (req, res) => {
        try {
          const result = await User.findOne({email:req.session.email});
          res.render('./user/dashboard',{name: result.name})
        } catch (error) {
          res.send(error.message);
        }
      }
    static about = (req, res) => {
        res.render('about', { user: req.session.email })
      }
    static contact = (req, res) => {
        res.render('contact', { user: req.session.email })
      }
    static contactform = async (req,res) =>{
    
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: 'f2018266216@gmail.com',
          pass: 'qiccvlgcesuuekjo' // hash password get from google account
        }

// https://www.youtube.com/watch?v=xvX4gWRWIVY
          });
    const str = `Name: ${req.body.name} <br/> Email: ${req.body.email} <br/> Phone: ${req.body.phone} <br/> Message: ${req.body.message}`
    const mailOptions = {
            from: 'f2018266216@gmail.com',
            to: 'f2018266216@umt.edu.pk',
            subject: 'Contact US',
            // text: `Hi Smartherd, thank you for your nice Node.js tutorials.
            //         I will donate 50$ for this course. Please send me payment options.`,
            html:  `${str}`      
          };
    transporter.sendMail(mailOptions, function(error, info){
            if (error) {
              console.log(error);
            }else {
              res.send('Email sent: ' + info.response);
            }
          });
    }
    static login = (req, res) => {
        res.render('./user/login')
      }
    static register = (req, res) => {
        res.render('./user/register')
      } 
    static create = async (req,res) => {
        try {
            if(req.body.password === req.body.cpassword){
                const HashPassword = await bcrypt.hash(req.body.password, 10)
                req.body.password = HashPassword
                const {name, email, password,cnic,contact} = req.body;
                const user = new User({
                name, email, password,cnic,contact});
                await user.save();
                res.redirect('/user/login');
            }else{
                res.send("<h1> Password Not Matched </h1>")
            }
         } catch (error) {
         res.send(error.message);
        }
    }
    static verifyLogin = async (req,res) => {
        try {
            const {email, password} = req.body;
            const result = await User.findOne({email:email});
            if(result != null){

                const isMatch = await bcrypt.compare(password, result.password)

                if(result.email == email && isMatch ){
                    req.session.email = req.body.email;
                    res.redirect("/user/dashboard")
                }else{
                    res.send("<h1>Invalid Email and Passwaord</h1>")
                }

            }else{
                res.send("<h1>You are Not Register User</h1>")
            }
            
        } catch (error) {
            res.send(error.message);
        }
    }

    static setting = (req,res) => { 
        res.render("./user/setting",{ user: req.session.email })
    }

    static logout = (req,res) => {
      req.session.destroy(function(err){
        if(err){
          res.send(err)
        }else{
          res.redirect('/')
        }
      })
    }


    static request = (req,res) => {
      res.render("./user/request")
    }




}

module.exports = userController;